const items = [
    {
      name: "Item 1",
      image: "./Images/pro1.jpg",
      price: 100,
      discount: 10,
    },
    {
      name: "Item 2",
      image: "/path/to/image2.jpg",
      price: 50,
      discount: 0,
    },
    {
      name: "Item 3",
      image: "/path/to/image3.jpg",
      price: 200,
      discount: 20,
    },
    {
        name: "Item 4",
        image: "/path/to/image4.jpg",
        price: 150,
        discount: 15,
        },
    {
        name: "Item 5",
        image: "/path/to/image5.jpg",
        price: 250,
        discount: 25,
        },
    {
        name: "Item 6",
        image: "/path/to/image6.jpg",
        price: 300,
        discount: 30,
        },
    {
        name: "Item 7",
        image: "/path/to/image7.jpg",
        price: 350,
        discount: 35,
        },
    {
        name: "Item 8",
        image: "/path/to/image8.jpg",
        price: 400,
        discount: 40,
        },
    {
        name: "Item 9",
        image: "/path/to/image9.jpg",
        price: 450,
        discount: 45,
        },
    {
        name: "Item 10",
        image: "/path/to/image10.jpg",
        price: 500,
        discount: 50,
        },
  ];
  
  export default items;
  